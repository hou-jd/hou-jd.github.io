def do_a_star(grid, start, end, display_message):
    """
    A* Path Planning Algorithm
    Uses the A* algorithm to find the shortest path in a grid environment.

    Args:
        grid (list of lists): The grid map where 1 represents free space, and 0 represents an obstacle.
        start (tuple): The starting position (col, row).
                      The starting position of the path.
        end (tuple): The goal position (col, row).
                    The destination position of the path.
        display_message (function): A function to display debug messages in the GUI.

    Returns:
        list: A list of (col, row) coordinates representing the shortest path from start to end.
    """

    # Get grid dimensions
    COL = len(grid)  # Number of columns
    ROW = len(grid[0])  # Number of rows

    # Allowed movement directions (up, down, left, right)
    moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

    # Open list: stores nodes to be explored
    # Format: (f-cost, g-cost, current node, parent node)
    open_list = [(0, 0, start, None)]
    
    # Closed set: tracks visited nodes to avoid redundant exploration
    closed_set = set()
    
    # Parent map: stores parent nodes for path reconstruction
    parent_map = {}
    
    # G-cost map: stores the total cost from the start node to each explored node
    g_cost_map = {start: 0}

    while open_list:
        # Sort open list by f-cost and extract the node with the lowest cost
        open_list.sort(key=lambda x: x[0])  
        _, g_cost, current, parent = open_list.pop(0)

        # Mark the node as visited
        closed_set.add(current)
        parent_map[current] = parent

        # If the goal is reached, reconstruct and return the path
        if current == end:
            path = []
            while current is not None:
                path.append(current)
                current = parent_map[current]
            path.reverse()  # Reverse to get the correct order
            display_message("The destination cell is found")
            return path

        # Explore all four possible movement directions
        for move in moves:
            neighbor = (current[0] + move[0], current[1] + move[1])

            # Ensure the neighbor is within grid bounds
            if not (0 <= neighbor[0] < COL and 0 <= neighbor[1] < ROW):
                continue

            # Skip obstacles and visited nodes
            if grid[neighbor[0]][neighbor[1]] == 0 or neighbor in closed_set:
                continue

            # Compute g(n), h(n), and f(n)
            new_g_cost = g_cost + 1  # Fixed movement cost per step
            h_cost = ((neighbor[0] - end[0]) ** 2 + (neighbor[1] - end[1]) ** 2) ** 0.5  # Euclidean heuristic
            f_cost = new_g_cost + h_cost  # A* total cost function

            # Check if the neighbor is already in open_list, update f-cost if needed
            in_open = False
            for i in range(len(open_list)):
                if open_list[i][2] == neighbor:
                    if f_cost < open_list[i][0]:  
                        open_list[i] = (f_cost, new_g_cost, neighbor, current)
                    in_open = True
                    break

            # If the neighbor is not in open_list, add it for exploration
            if not in_open:
                open_list.append((f_cost, new_g_cost, neighbor, current))

    # If no path is found, return an empty list
    display_message("No path found")
    return []


