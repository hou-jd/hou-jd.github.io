# Start of skeleton code

# Q1 Answer: 741
# Q2 Answer: 24
# Q3 Answer: 1998-05-16

import csv
import datetime

# Temperature lookup table (maps hex values to Celsius)
temp_lookup = {i: 30.0 + (i - 0xA0) * 0.1 for i in range(0xA0, 0xE0)}

# Compute checksum
def calculate_checksum(frame):
    """
    Compute the checksum for a data frame:
    Formula: (255 - (sum(frame[2:25]) % 256)) % 256
    Only considers SYS_ID to TME (bytes 3 to 25).
    """
    checksum = sum(frame[2:25]) % 256  
    return (255 - checksum) % 256

# Open the binary input file
input_file = open("binaryFileC_40.bin", 'rb')

# Open the CSV output file
output_file = open("11517518.csv", 'w', newline='')  
csv_writer = csv.writer(output_file)

# Write the CSV header row
csv_writer.writerow(["Header", "SYS_ID", "DEST_ID", "COMP_ID", "SEQ", "TYPE", "P", "RPM", "Voltage", "Current", 
                     "MOS_Temp", "CAP_Temp", "T", "Time", "Checksum"])

# Initialize variables
frame_count = 0  # Count the number of complete data frames
corrupt_count = 0  # Count the number of corrupted data frames
timestamps = []  # Store all timestamps
buffer = []  # Buffer to store 26-byte complete data frames
prev_seq = -1  # Track previous SEQ value to detect missing frames

# Read the binary data stream
byte = input_file.read(1)
while byte:
    # Append byte to buffer
    buffer.append(int.from_bytes(byte, 'big'))

    # Maintain a maximum buffer size of 26 bytes
    if len(buffer) > 26:
        buffer.pop(0)

    # Check if a complete 26-byte frame is detected and starts with '%%'
    if len(buffer) == 26 and buffer[0] == 37 and buffer[1] == 37:  # '%%' header
        frame = buffer.copy()  # Copy complete data frame
        buffer.clear()  # Clear buffer for next frame

        # Compute checksum and verify data integrity
        calculated_checksum = calculate_checksum(frame)
        received_checksum = frame[-1]
        is_corrupt = calculated_checksum != received_checksum
        if is_corrupt:
            corrupt_count += 1  # Count corrupted data frames

        # Parse frame fields
        sys_id = int(frame[2])  # Sender system ID
        dest_id = int(frame[3])  # Destination device ID
        comp_id = int(frame[4])  # Component ID
        seq = int(frame[5])  # Frame sequence number
        data_type = int(frame[6])  # Data type
        rpm = int((frame[8] << 8) | frame[9])  # Parse 16-bit RPM speed
        voltage = int((frame[10] << 8) | frame[11])  # Parse 16-bit Voltage (millivolts)
        current = int(((frame[12] << 8) | frame[13]) - 0x10000 if frame[12] & 0x80 else (frame[12] << 8) | frame[13])  # Parse 16-bit Current (milliamps)

        # Parse MOSFET temperature
        mos_temp = temp_lookup.get(frame[14], 0.0)  # Default to 0.0 if out of range

        # Strict validation for CAP_Temp, setting it to 0.0 if out of range
        cap_raw_value = frame[15]  # Store original raw hex value
        if cap_raw_value < 0xA0 or cap_raw_value > 0xDF:
            cap_temp = 0.0  # Force to 0.0 if out of range
        else:
            cap_temp = temp_lookup[cap_raw_value]

        # Ensure CAP_Temp remains within valid range, otherwise set to 0.0
        cap_temp = round(cap_temp, 2) if 30.0 <= cap_temp <= 36.3 else 0.0

        # Debug print statements for checking values
        print(f"SEQ: {seq}, Raw CAP_Temp: {cap_raw_value}, Parsed: {cap_temp}")

        # Check for missing frames
        if frame_count > 0 and seq != (prev_seq + 1) % 256:
            print(f"Warning: Possible frame loss detected at SEQ {seq}")
        prev_seq = seq  # Update previous SEQ

        # Parse 64-bit timestamp (stored in Unix microseconds format)
        timestamp = int.from_bytes(frame[17:25], byteorder='big')
        timestamps.append(timestamp)  # Store all timestamps

        # Write parsed data to CSV, ensuring correct data types
        csv_writer.writerow([
            "~~", sys_id, dest_id, comp_id, seq, data_type, "P", rpm, voltage, current,
            round(mos_temp, 2), cap_temp, "T", timestamp, received_checksum
        ])

        # Count complete data frames
        frame_count += 1

    # Read next byte
    byte = input_file.read(1)

# End of file reading
print("End of file reached")
input_file.close()
output_file.close()

# Compute additional question answers
q1_answer = frame_count  # Number of complete data frames
q2_answer = corrupt_count  # Number of corrupted data frames
q3_answer = (
    datetime.datetime.utcfromtimestamp(min(timestamps) // 1_000_000).strftime('%Y-%m-%d')
    if timestamps else "N/A"
)  # Compute earliest timestamp and convert to YYYY-MM-DD format

# Print final results
print(f"Q1 Answer: {q1_answer}")  # Output number of complete data frames
print(f"Q2 Answer: {q2_answer}")  # Output number of corrupted data frames
print(f"Q3 Answer: {q3_answer}")  # Output earliest timestamp in YYYY-MM-DD format

# End of skeleton code

